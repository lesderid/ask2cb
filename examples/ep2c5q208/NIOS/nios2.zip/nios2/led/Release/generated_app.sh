#! /bin/sh
#
 
# DO NOT MODIFY THIS FILE
#
#   Changing this file will have subtle consequences
#   which will almost certainly lead to a nonfunctioning
#   system. If you do modify this file, be aware that your
#   changes will be overwritten and lost when this file
#   is generated again.
#
# DO NOT MODIFY THIS FILE
 
SYSTEM_CONFIG_DIR=/cygdrive/d/ask2cb_nios/nios2/led_syslib/Release
