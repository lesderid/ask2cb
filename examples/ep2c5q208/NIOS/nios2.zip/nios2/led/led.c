#include "stdio.h"
#include "unistd.h"
#include "system.h"

#define _LED 1

typedef struct
{
    unsigned long int DATA;
    unsigned long int DIRECTION;
    unsigned long int INTERRUPT_MASK;
    unsigned long int EDGE_CAPTURE;
}PIO_STR;

#ifdef _LED
#define LED ((PIO_STR *)PIO_LED_BASE)
#endif

int main()
{ 
  int i;
  
  while(1)
  {
    for (i=0; i<8; i++){
        LED->DATA = ~(1<<i);
        usleep(50000);
    }
  }
  return 0;
}

